<?php
session_start();

$servername = 'localhost';
$username = 'root';
$password = '';
$database = 'baamuptown';

$con = mysqli_connect($servername, $username, $password, $database);

?>